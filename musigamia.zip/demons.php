<?php
set_time_limit(0);
include('classes.php');

$id = new url();
$id->id = $_GET['id'];
$link = "http://www.goear.com/tracker758.php?f=".$_GET['id'];
$id->link = $link;
//$id->set_link();
$id->get_url_contents();
$id->get_mp3();

header('Location: ' .$id->mp3);
exit();
?>