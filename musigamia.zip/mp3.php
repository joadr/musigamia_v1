<?php

set_time_limit(0);

include('classes.php');

$id = new url();
$id->id = $_GET['id'];
$link = "http://www.goear.com/tracker758.php?f=".$_GET['id'];
$id->link = $link;
$id->get_url_contents();
$id->get_mp3();
$id->obtener_datos();


$headers = get_headers($id->mp3, 1);

header('Content-Length: ' . $headers['Content-Length']);
header('Accept-Ranges: bytes');
header('Connection: close');
header("Content-Type: application/force-download"); 
header('Content-Description: File Transfer'); 
header('Content-Disposition: attachment; filename="'.$id->datos.'.mp3"');
readfile($id->mp3);
?>