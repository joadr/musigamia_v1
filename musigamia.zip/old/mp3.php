<?php

set_time_limit(0);

$id = $_GET['id'];

// Creamos la función para obtener el html de una url con CURL
function get_url_contents($url){
	$crl = curl_init();
	$timeout = 25;
	curl_setopt ($crl, CURLOPT_URL,$url);
	curl_setopt ($crl, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($crl, CURLOPT_CONNECTTIMEOUT, $timeout);
	$ret = curl_exec($crl);
	curl_close($crl);
	return $ret;
}

// Obtenemos el xml con los datos de la canción
$content = get_url_contents('http://www.goear.com/tracker758.php?f='.$id);

// Creamos una función para extraer los mp3 de las canciones
function get_mp3($source) {
  preg_match_all('#path=\"(.[^\"]*)#',
                   $source,
                   $matches,
                   PREG_PATTERN_ORDER);

  return $matches[1];
}

// Creamos una función para obtener el nombre de la canción y el artista
function get_artist($source) {
  preg_match_all('#artist=\"(.[^\"]*)#',
                   $source,
                   $matches,
                   PREG_PATTERN_ORDER);
  return $matches[1];
}

function get_title($source) {
  preg_match_all('#title=\"(.[^\"]*)#',
                   $source,
                   $matches,
                   PREG_PATTERN_ORDER);			   
  return $matches[1];
}

// Ejecutamos la función para obtener el título de la canción		  //
$titulo = get_title($content);										  //
$titulo = implode("", $titulo);										  //
// -----------------------------------------------------------------  //

// Ejecutamos la función para obtener el artista de la canción        //
$artista = get_artist($content);									  //
$artista = implode("", $artista);									  //
// -----------------------------------------------------------------  //

$datos = $titulo . " - " . $artista;

$mp3 = get_mp3($content);
$mp3 = implode("", $mp3);


$headers = get_headers($mp3, 1);

if (!is_null($id)) {
        //header('Content-type: audio/mpeg');
		header('Content-Length: ' . $headers['Content-Length']);
		header('Accept-Ranges: bytes');
		header('Connection: close');
		header("Content-Type: application/force-download"); 
   		header('Content-Description: File Transfer'); 
		header('Content-Disposition: attachment; filename='.$datos.'.mp3');
		//header('Content-Type: application/octet-stream');
		//echo "\"".filesize($mp3)."\"";
		//echo $headers['Content-Length'];
        readfile($mp3);
		//echo "se lee";
}
?>