<?php
// El criterio de busqueda es la variable por URL
if(!isset($_POST['buscar'])){
	$busqueda = $_GET['buscar'];
} else {
	$busqueda = $_POST['buscar'];
}
// Reemplazamos los espacios con signos "+" para que sea compatible con la otra web
$busquedaf = str_replace(" ", "-", $busqueda);

if(!isset($_POST['page'])){
	$pagina = $_GET['page'];
} else {
	$pagina = $_POST['page'];
}
if(!$pagina){
	$page = "1";
} else {
	$page = $pagina;
}
// Creamos la función para obtener el html de una url con CURL
function get_url_contents($url){
	$crl = curl_init();
	$timeout = 25;
	curl_setopt ($crl, CURLOPT_URL,$url);
	curl_setopt ($crl, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($crl, CURLOPT_CONNECTTIMEOUT, $timeout);
	$ret = curl_exec($crl);
	curl_close($crl);
	return $ret;
}

// Conseguimos el contenido de la página haciendo la busquedaf con la variable obtenida por URL
$captura = get_url_contents("http://www.goear.com/search/".$busquedaf."/".$page."/");
$captura2 = get_url_contents("http://www.goear.com/search/".$busquedaf."/".++$page);
$todo = $captura." ".$captura2;
//$todo = $captura;

// Creamos una función para obtener un determinado texto
function get_tag( $attr, $value, $xml, $tag=null ) {
  if( is_null($tag) )
    $tag = '\w+';
  else
    $tag = preg_quote($tag);

  $attr = preg_quote($attr);
  $value = preg_quote($value);

  $tag_regex = "/<(".$tag.")[^>]*$attr\s*=\s*".
                "(['\"])$value\\2[^>]*>(.*?)<\/\\1>/";

  preg_match_all($tag_regex,
                 $xml,
                 $matches,
                 PREG_PATTERN_ORDER);

  return $matches[3];
}
function get_tag2( $tag, $xml ) {
  $tag = preg_quote($tag);
  preg_match_all('{<'.$tag.'[^>]*>(.*?)</'.$tag.'>}',
                   $xml,
                   $matches,
                   PREG_PATTERN_ORDER);

  return $matches[1];
}

// creamos una función para extraer los id de las canciones
function get_code($source) {
  //$source = preg_quote($source);
  preg_match_all('#href=\"listen\/(.[^\/]*)#',
                   $source,
                   $matches,
                   PREG_PATTERN_ORDER);

  return $matches[1];
}

// creamos una función para extraer el autor
function get_author($source) {
  //$source = preg_quote($source);
  //$source = implode("", $source);
  preg_match_all('#<span class="song">(.*)</span>#U',
                   $source,
                   $matches,
                   PREG_PATTERN_ORDER);

  return $matches[1];
}

// Creamos la función para extraer el grupo
function get_group($source) {
  //$source = preg_quote($source);
  //$source = implode("", $source);
  preg_match_all('#<span class="group">(.*)</span>#U',
                   $source,
                   $matches,
                   PREG_PATTERN_ORDER);

  return $matches[1];
}

// creamos una función cambiar los links de las canciones
function change_link($source, $id, $autor) {
  //$source = preg_quote($source);
  $id = implode("", $id);
  $autor = implode("", $autor);
  $replacement = 'class="song" id="'.$id.'" href="#">'.$autor;
  $result = preg_replace('#href=\"listen\/(.[^\<]*)#',
                   $replacement,
                   $source,
				   -1,
				   $count);
  return $result;
}
function change_name($source, $replacement) {
  //$source = preg_quote($source);
/*  $id = implode("", $id); */
  $replacement = "fleto";
  $result = preg_replace('@"#">(.[^\<]*)@',
                   $replacement,
                   $source,
				   -1,
				   $count);
  return $result;
}

$order   = array("\r\n", "\n", "\r", "\t");
$replace = ' ';
$todo = str_replace($order, $replace, $todo);

//$todo = str_replace('</ol>', '</div>', $busqueda);
$casitodo = get_tag('id', 'results', $todo, 'ol');
$casitodo = str_replace('<li class="even">', '<li>', $casitodo);
$casitodo = implode("", $casitodo);

$extracto = get_tag2('li', $casitodo);
?>
<!DOCTYPE html> 
<html> 
	<head> 
	<title>MusikAddict Mobile</title> 
	
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
	<link rel="stylesheet" href="style/themes/Red.min.css">
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0rc2/jquery.mobile.structure-1.0rc2.min.css" />
    <link href="style/jplayer/jplayer.light.monday.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="js/jquery-1.7.min.js"></script>
    <script type="text/javascript" src="js/jquery.jplayer.min.js"></script>
    <script type="text/javascript" src="js/jplayer.playlist.min.js"></script>
	<script type="text/javascript" src="js/jquery.mobile-1.0.min.js"></script>
</head> 
<body>
<div data-role="page" id="Search">

	<div data-role="header">
    	<a href="#home" data-icon="back">Back</a>
		<h1>Search for Musik</h1>
	</div><!-- /header -->

	<div data-role="content">
		<script>
		$("#Search").bind('pageinit', function() {
			$('li[data-icon*="plus"]').click(function() {
				window.myPlaylist.add({
					title: $(this).attr("titulo"),
					artist: $(this).attr("grupo"),
					mp3:"demons.php?id="+$(this).attr("id")
				});
				alert("Song added to actual playlist");
			});
		});
        </script>	
		<?php
        // Bucle para mostrar los resultados:
        echo '<ul data-role="listview">';
        foreach($extracto as $lista){
            $idCanciones = get_code($lista);
            $titulo = get_author($lista);
            $titulo = implode("", $titulo);
			$grupo = get_group($lista);
            $grupo = implode("", $grupo);
            $idCanciones = implode("", $idCanciones);
            //$awa = change_link($lista, $idCanciones, $titulo);
            //print_r($awa);
			echo '<li class="lishow" data-icon="plus" id="'.$idCanciones.'" titulo="'.$titulo.'" grupo="'.$grupo.'" >';
            print_r('<a href="javascript:;" data-rel="dialog"><span class="cancion">'.$titulo.' - '.$grupo.'</a>');
            echo "</li>"."\r\n";
        }
        echo "</ul>";
        ?>
        <div style="margin: 10px auto 0 auto;">
            <a href="search.php?buscar=<?php echo $busquedaf; ?>&page=<?php if($page == 2){ echo "2"; } else { echo $page-3; } ?>" id="prev" data-role="button" data-icon="arrow-l" data-inline="true">Anterior</a>
            
            <a href="search.php?buscar=<?php echo $busquedaf; ?>&page=<?php echo ++$page; ?>" id="next" data-role="button" data-icon="arrow-r" data-iconpos="right" data-inline="true">Siguiente</a>
        </div>
        <div id="hidden4load"></div>
    </div><!-- /content -->

	<div data-role="footer">
		<h4>MusikAddict</h4>
	</div><!-- /footer -->
</div><!-- /page -->
</body>
</html>
<?php die; ?>