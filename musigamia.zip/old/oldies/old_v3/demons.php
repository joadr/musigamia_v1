<?php
set_time_limit(0);

$id = $_GET['id'];

// Creamos la función para obtener el html de una url con CURL
function get_url_contents($url){
	$crl = curl_init();
	$timeout = 25;
	curl_setopt ($crl, CURLOPT_URL,$url);
	curl_setopt ($crl, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($crl, CURLOPT_CONNECTTIMEOUT, $timeout);
	$ret = curl_exec($crl);
	curl_close($crl);
	return $ret;
}

// Obtenemos el xml con los datos de la canción
$content = get_url_contents('http://www.goear.com/tracker758.php?f='.$id);

// Creamos una función para extraer los mp3 de las canciones
function get_mp3($source) {
  preg_match_all('#path=\"(.[^\"]*)#',
                   $source,
                   $matches,
                   PREG_PATTERN_ORDER);

  return $matches[1];
}

$mp3 = get_mp3($content);
$mp3 = implode("", $mp3);

//include('smartReadFile.php');

//smartReadFile($mp3, "streaming.mp3", "audio/mpeg");

//$headers = get_headers($mp3, 1);

if (!is_null($id)) {
		/*header('Content-Length: ' . $headers['Content-Length']);
		header('Accept-Ranges: bytes');
		header('Connection: close');
		header('ETag: '. $headers['ETag']);
		header("Content-Type: audio/mpeg"); 
		header('Content-Disposition: inline; filename='.$datos.'.mp3');
		header("Content-Transfer-Encoding: binary");
		header('Content-Type: application/octet-stream');
		echo $headers['Content-Length'];
        readfile($mp3);
		echo "se lee";*/
		header('Location: ' .$mp3);
		exit();
}
?>